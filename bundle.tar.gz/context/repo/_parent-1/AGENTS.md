# ATURAN TETAP — make.fun

File ini dibaca Hermes di awal sesi. Simpan sebagai `AGENTS.md` di folder markas make.fun user: `~\Documents\Makefun`. Sesi Hermes selalu dibuka dari folder markas ini. Untuk tiap kompetisi, buat SUBFOLDER baru khusus kompetisi itu di dalam folder markas (nama = slug kompetisi) dan kerjakan semua build di subfolder itu — jangan mencampur file antar-kompetisi di folder markas.

## Pemicu kerja

Bila user mengirim **link make.fun** (mis. `https://make.fun/bounty/<slug>`) atau menyebut slug kompetisi, itu adalah **PERINTAH KERJA** — bukan bahan obrolan dan bukan pertanyaan. Langsung kerjakan alur di bawah tanpa menunggu perintah tambahan.

## Alur kerja

1. Baca brief resmi kompetisi itu: `make.fun/skill.md` dan halaman kompetisinya.
2. Laporkan ringkas ke user: tugasnya apa, hadiah dan jumlah tempat berbayar, deadline, jumlah submisi saat ini, escrow terkunci atau tidak.
3. **Cek gerbang sesi rekam SEBELUM membangun apa pun:**
   - Sesi berjalan di dalam jendela kompetisi, direkam dengan record command kit.
   - Provider harus yang terverifikasi lolos gerbang transkrip (OpenRouter). **JANGAN provider custom** (mis. endpoint reseller) — sesi dengan provider custom tidak bisa dibundel dan hadiah hangus.
   - Sesi dimulai di folder bersih, dan perintah build adalah pesan pertama sesi.
   - Bila satu saja syarat tidak terpenuhi: **berhenti, jelaskan ke user, jangan membangun diam-diam.**
4. Bangun persis sesuai brief: repo GitHub publik milik akun user (dibuat sesudah kompetisi dibuka), `main.ts` (Node 22) di root, file vendor kit utuh tidak diubah, folder aplikasi statis, 3–4 screenshot ASLI dari hasil build sendiri.
5. Jalankan check dari kit; perbaiki semua yang gagal; lalu submit sebelum deadline. Maks 5 submisi/hari, 10 total — submisi terakhir sebelum deadline adalah entri final.
6. Laporkan ringkas tiap tahap selesai, dengan bukti: link repo dan ID submisi.

## Aturan keras

- Hanya kompetisi **gratis**. Jangan pernah membayar entry fee dalam bentuk apa pun.
- Jangan menghubungi penyelenggara atau pihak luar atas nama user. Jangan mempublikasikan apa pun di luar submisi resmi kompetisi.
- Semua aset harus **orisinal**: tanpa logo, artwork, atau materi berhak cipta milik pihak lain (mis. Rockstar/GTA). Nama dan data faktual sesuai brief boleh dipakai bila brief memang menyuruhnya, teks panduan ditulis dengan kata-kata sendiri dan mencantumkan sumber.
- Bila kuota provider habis di tengah sesi rekam: **berhenti dan laporkan**. JANGAN ganti provider di tengah sesi (merusak rekaman). Ganti MODEL sesama provider yang sama boleh; ganti key sesama provider yang sama boleh.
- Jangan mengarang hasil. Yang gagal tulis gagal beserta alasannya; yang belum terverifikasi tulis belum terverifikasi.
- Bahasa laporan ke user: Bahasa Indonesia, ringkas.

## Peringatan provider sesi rekam — WAJIB berhenti dan peringatkan user

- Sebelum membangun entri kompetisi apa pun, periksa provider yang sedang aktif di sesi ini.
- Satu-satunya provider yang TERBUKTI lolos gerbang rekam make.fun adalah OpenRouter. XingChi (provider custom) SUDAH TERBUKTI GAGAL gerbang. NVIDIA NIM BELUM terverifikasi.
- Bila provider aktif BUKAN OpenRouter: BERHENTI TOTAL. Jangan membangun, jangan menulis kode, jangan mengunduh apa pun untuk kompetisi itu. Tampilkan peringatan ini ke user, persis maknanya:

  "⚠️ Sesi ini butuh rekaman yang lolos gerbang make.fun, dan provider yang terbukti lolos hanya OpenRouter. Provider aktif sekarang BUKAN OpenRouter, jadi sesi ini tidak bisa menghasilkan entri berbayar. Ganti dulu: jalankan hermes model, pilih OpenRouter, lalu mulai sesi BARU dari subfolder bersih. Sesi yang sudah berjalan di provider lain tidak bisa diselamatkan — jangan dilanjutkan untuk kompetisi."

- Bila user tetap menyuruh lanjut di provider yang salah, ulangi peringatan ini satu kali dan nyatakan bahwa hasilnya paling baik hanya entri handed-over tanpa tempat berbayar; kerjakan hanya bila user menyetujui itu secara eksplisit.
- Jangan pernah mengganti provider di tengah sesi rekam, dengan alasan apa pun.
